define(
({
		previousMessage: "Předchozí volby",
		nextMessage: "Další volby"
})
);
