define(
({
	previousMessage: "Попередні варіанти",
	nextMessage: "Додаткові варіанти"
})
);
