define(
({
	loadingState: "กำลังโหลด...",
	errorState: "ขออภัย เกิดข้อผิดพลาด"
})
);
