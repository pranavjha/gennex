define([
	"./_base/module",
	"./infrastructure-module",

	"./general-module",
	"./tree/module",
	"./editor/module",
	"./form/module",
	"./layout/module",

	"./_BidiSupport/module"
], 1);


